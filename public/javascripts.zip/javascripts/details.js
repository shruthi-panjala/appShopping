



var shipdetailsarr=[];

function insert( ) {
   var ip=document.getElementsByTagName("input");
    for(var i=0;i<ip.length;i++)
        {
         console.log(ip[i].value);
            
        }
    
/* shipdetailsarr.push(firstname.value,lastname.value,email.value,telephone.value,fax.value,company.value,
 cid.value,add1.value,add2.value,country.value,region.value,city.value,postcode.value); 
     console.log(shipdetailsarr);
    alert(document.getElementById("firstname").value);*/
}