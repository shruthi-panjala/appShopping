var toggleVisibility = function(element1,element2) {
	    if(element2.style.display=='block'){
	        element2.style.display='none';
            element1.style.display='block';
	    } else {
	        element1.style.display='block';
	    }
	    
	};